document.addEventListener('DOMContentLoaded', () => {
  const lobby = document.getElementById('lobby');
  const game = document.getElementById('game');
  const inviteButton = document.getElementById('invite-button');
  const notifications = document.getElementById('notifications');
  const chessboard = document.getElementById('chessboard');
  const gameStatus = document.getElementById('game-status');
  const playerList = document.getElementById('player-list');
  const chatMessages = document.getElementById('chat-messages');
  const chatInput = document.getElementById('chat-input');
  const sendMessage = document.getElementById('send-message');
  const usernameDisplay = document.getElementById('username');
  const logoutButton = document.getElementById('logout');
  const logo = document.getElementById('logo');
  const title = document.getElementById('title');

  let currentGameID = null;
  let selectedPiece = null;
  let currentTurn = 'white';
  let playerColor = null;

  const username = prompt('Enter your username');
  usernameDisplay.textContent = username;

  const ws = new WebSocket('wss://' + window.location.host);

  ws.onopen = () => {
    ws.send(JSON.stringify({ type: 'join', username }));
  };

  ws.onmessage = (message) => {
    const data = JSON.parse(message.data);
    console.log('Received message:', data);

    switch (data.type) {
      case 'playerList':
        updatePlayerList(data.players);
        break;
      case 'invite':
        handleInvite(data.from);
        break;
      case 'startGame':
        startGame(data);
        break;
      case 'updateGame':
        updateGame(data);
        break;
      case 'drawOffered':
        handleDrawOffer(data.from);
        break;
      case 'gameOver':
        handleGameOver(data.winner);
        break;
      case 'chat':
        handleChatMessage(data.username, data.message);
        break;
      case 'invalidMove':
        alert('Invalid move. Try again.');
        currentTurn = data.turn;
        break;
    }
  };

  logoutButton.addEventListener('click', () => {
    ws.close();
    location.reload();
  });

  logo.addEventListener('click', () => {
    window.location.href = 'leaderboard.html';
  });

  title.addEventListener('click', () => {
    lobby.style.display = 'block';
    game.style.display = 'none';
  });

  inviteButton.addEventListener('click', () => {
    const opponent = prompt('Enter the username of the player you want to invite');
    ws.send(JSON.stringify({ type: 'invite', opponent, username }));
  });

  sendMessage.addEventListener('click', () => {
    const message = chatInput.value;
    chatInput.value = '';
    ws.send(JSON.stringify({ type: 'chat', message, username, gameID: currentGameID }));
  });

  function updatePlayerList(players) {
    playerList.innerHTML = '';
    players.forEach(player => {
      const playerDiv = document.createElement('div');
      playerDiv.textContent = player;
      playerDiv.addEventListener('click', () => {
        ws.send(JSON.stringify({ type: 'invite', opponent: player, username }));
      });
      playerList.appendChild(playerDiv);
    });
  }

  function handleInvite(from) {
    const invite = document.createElement('div');
    invite.textContent = `${from} invited you to play`;
    const acceptButton = document.createElement('button');
    acceptButton.textContent = 'Accept';
    acceptButton.addEventListener('click', () => {
      ws.send(JSON.stringify({ type: 'acceptInvite', from, username }));
      notifications.removeChild(invite);
    });
    invite.appendChild(acceptButton);
    notifications.appendChild(invite);
  }

  function startGame(data) {
    currentGameID = data.gameID;
    lobby.style.display = 'none';
    game.style.display = 'block';
    playerColor = data.players[0] === username ? 'white' : 'black';
    renderChessboard(data.board);
    gameStatus.textContent = `Black vs White`;
  }

  function updateGame(data) {
    renderChessboard(data.board);
    gameStatus.textContent = `Black vs White`;
    currentTurn = data.turn === 'w' ? 'white' : 'black';
    if (currentTurn === 'white') {
      gameStatus.textContent += ' - White\'s Turn';
    } else {
      gameStatus.textContent += ' - Black\'s Turn';
    }
  }

  function handleDrawOffer(from) {
    const drawOffer = document.createElement('div');
    drawOffer.textContent = `${from} offered a draw`;
    const acceptDrawButton = document.createElement('button');
    acceptDrawButton.textContent = 'Accept Draw';
    acceptDrawButton.addEventListener('click', () => {
      ws.send(JSON.stringify({ type: 'acceptDraw', gameID: currentGameID, username }));
      notifications.removeChild(drawOffer);
    });
    drawOffer.appendChild(acceptDrawButton);
    notifications.appendChild(drawOffer);
  }

  function handleGameOver(winner) {
    alert(`Game over! ${winner} wins!`);
    location.reload();
  }

  function handleChatMessage(username, message) {
    chatMessages.innerHTML += `<div>${username}: ${message}</div>`;
  }

  function renderChessboard(board) {
    chessboard.innerHTML = '';
    board.forEach((row, rowIndex) => {
      row.forEach((cell, colIndex) => {
        const square = document.createElement('div');
        square.classList.add((rowIndex + colIndex) % 2 === 0 ? 'white' : 'black');

        if (cell) {
          const piece = document.createElement('span');
          piece.classList.add('piece');
          piece.textContent = getChessPieceUnicode(cell);
          piece.classList.add(cell.color === 'w' ? 'white-piece' : 'black-piece');
          piece.addEventListener('mouseover', () => {
            piece.style.cursor = 'pointer';
          });
          piece.addEventListener('click', () => {
            if (playerColor === currentTurn) {
              if (selectedPiece && selectedPiece.row === rowIndex && selectedPiece.col === colIndex) {
                piece.classList.remove('selected');
                selectedPiece = null;
              } else if (cell.color === playerColor[0]) {
                if (selectedPiece) {
                  const previousPiece = document.querySelector('.selected');
                  if (previousPiece) previousPiece.classList.remove('selected');
                }
                piece.classList.add('selected');
                selectedPiece = { row: rowIndex, col: colIndex };
              }
            }
          });
          square.appendChild(piece);
        }

        square.addEventListener('click', () => {
          if (playerColor === currentTurn && selectedPiece && !(selectedPiece.row === rowIndex && selectedPiece.col === colIndex)) {
            ws.send(JSON.stringify({
              type: 'move',
              gameID: currentGameID,
              color: playerColor,
              move: { from: { row: selectedPiece.row, col: selectedPiece.col }, to: { row: rowIndex, col: colIndex } }
            }));
            selectedPiece = null;
            const previousPiece = document.querySelector('.selected');
            if (previousPiece) previousPiece.classList.remove('selected');
          }
        });

        chessboard.appendChild(square);
      });
    });
  }

  function getChessPieceUnicode(piece) {
    const pieces = {
      'p': { 'w': '♙', 'b': '♟' },
      'r': { 'w': '♖', 'b': '♜' },
      'n': { 'w': '♘', 'b': '♞' },
      'b': { 'w': '♗', 'b': '♝' },
      'q': { 'w': '♕', 'b': '♛' },
      'k': { 'w': '♔', 'b': '♚' }
    };
    return pieces[piece.type][piece.color];
  }

  // Function to manually move a piece using chess notation
  window.movePiece = function (from, to) {
    const fromPos = convertToChessArrayPosition(from);
    const toPos = convertToChessArrayPosition(to);
    console.log(`Attempting to move from ${from} (${fromPos.row},${fromPos.col}) to ${to} (${toPos.row},${toPos.col})`);
    ws.send(JSON.stringify({
      type: 'move',
      gameID: currentGameID,
      color: playerColor,
      move: { from: fromPos, to: toPos }
    }));
  }

  function convertToChessArrayPosition(position) {
    const files = 'abcdefgh';
    const col = files.indexOf(position[0]);
    const row = 8 - parseInt(position[1]);
    return { row, col };
  }

  // Example usage: window.movePiece('e2', 'e4')
});

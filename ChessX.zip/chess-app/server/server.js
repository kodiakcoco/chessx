const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');
const { Chess } = require('chess.js');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

let players = [];
let games = {};
let leaderboard = {};

wss.on('connection', (ws) => {
  ws.on('message', (message) => {
    const data = JSON.parse(message);
    console.log('Received message:', data);

    switch (data.type) {
      case 'join':
        players.push({ id: ws, username: data.username });
        updatePlayerList();
        break;
      case 'invite':
        const opponent = players.find(player => player.username === data.opponent);
        if (opponent) {
          opponent.id.send(JSON.stringify({ type: 'invite', from: data.username }));
        }
        break;
      case 'acceptInvite':
        startGame(data.from, data.username);
        break;
      case 'move':
        handleMove(data);
        break;
      case 'resign':
        handleResignation(data);
        break;
      case 'offerDraw':
        handleDrawOffer(data);
        break;
      case 'acceptDraw':
        handleDrawAcceptance(data);
        break;
      case 'chat':
        broadcastToGame(data.gameID, { type: 'chat', username: data.username, message: data.message });
        break;
    }
  });

  ws.on('close', () => {
    players = players.filter(player => player.id !== ws);
    updatePlayerList();
  });
});

function updatePlayerList() {
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify({ type: 'playerList', players: players.map(player => player.username) }));
    }
  });
}

function startGame(player1, player2) {
  const gameID = `${player1}-vs-${player2}`;
  const chess = new Chess();
  games[gameID] = {
    chess,
    players: [player1, player2],
    turn: 'white',
  };
  leaderboard[player1] = (leaderboard[player1] || 0) + 1;
  leaderboard[player2] = (leaderboard[player2] || 0) + 1;
  broadcastToGame(gameID, { type: 'startGame', gameID, board: chess.board(), players: [player1, player2] });
}

function handleMove(data) {
  const game = games[data.gameID];
  if (game && game.turn === data.color) {
    try {
      console.log(`Processing move for ${data.color}: ${data.move.from.row},${data.move.from.col} to ${data.move.to.row},${data.move.to.col}`);
      const from = convertToChessNotation(data.move.from);
      const to = convertToChessNotation(data.move.to);
      const move = game.chess.move({ from, to, promotion: 'q' });
      if (move) {
        game.turn = game.chess.turn() === 'w' ? 'white' : 'black';
        console.log('Move successful:', move);
        broadcastToGame(data.gameID, { type: 'updateGame', board: game.chess.board(), turn: game.chess.turn() });
        checkForEndgame(data.gameID);
      } else {
        console.log('Invalid move:', data.move);
        broadcastToGame(data.gameID, { type: 'invalidMove', turn: game.turn });
      }
    } catch (error) {
      console.log('Error processing move:', error.message);
      broadcastToGame(data.gameID, { type: 'invalidMove', turn: game.turn });
    }
  }
}

function handleResignation(data) {
  const game = games[data.gameID];
  if (game) {
    const winner = game.players.find(player => player !== data.username);
    broadcastToGame(data.gameID, { type: 'gameOver', winner });
    delete games[data.gameID];
  }
}

function handleDrawOffer(data) {
  const game = games[data.gameID];
  if (game) {
    const opponent = game.players.find(player => player !== data.username);
    const opponentSocket = players.find(player => player.username === opponent).id;
    opponentSocket.send(JSON.stringify({ type: 'drawOffered', from: data.username }));
  }
}

function handleDrawAcceptance(data) {
  const game = games[data.gameID];
  if (game) {
    broadcastToGame(data.gameID, { type: 'gameOver', winner: 'Draw' });
    delete games[data.gameID];
  }
}

function checkForEndgame(gameID) {
  const game = games[gameID];
  console.log('Checking for endgame conditions...');
  if (game.chess.isCheckmate()) {
    const winner = game.turn === 'white' ? game.players[1] : game.players[0];
    broadcastToGame(gameID, { type: 'gameOver', winner });
    delete games[gameID];
  } else if (game.chess.isStalemate() || game.chess.isDraw() || game.chess.isThreefoldRepetition()) {
    broadcastToGame(gameID, { type: 'gameOver', winner: 'Draw' });
    delete games[gameID];
  }
}

function convertToChessNotation(position) {
  const files = 'abcdefgh';
  return files[position.col] + (8 - position.row);
}

function broadcastToGame(gameID, data) {
  const game = games[gameID];
  game.players.forEach(player => {
    const playerSocket = players.find(p => p.username === player).id;
    if (playerSocket.readyState === WebSocket.OPEN) {
      playerSocket.send(JSON.stringify(data));
    }
  });
}

app.use(express.static(path.join(__dirname, '../public')));

app.get('/leaderboard', (req, res) => {
  res.json(leaderboard);
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../public', 'error.html'));
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server is listening on port ${PORT}`);
});
